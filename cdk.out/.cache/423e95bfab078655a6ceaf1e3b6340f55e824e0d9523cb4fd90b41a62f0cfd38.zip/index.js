"use strict";exports.handler=async e=>{let r=e.request.privateChallengeParameters.secretLoginCode,n=e.request.challengeAnswer;return{answerCorrect:r===n}};
//# sourceMappingURL=index.js.map
